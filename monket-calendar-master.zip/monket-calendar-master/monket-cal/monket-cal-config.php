<?php
    define('SITE_DIR', '/~karl/monket-calendar/monket-cal/');
    define('CALENDAR_DIR', '/Users/karl/Sites/monket-calendar/monket-cal/calendars/');
    define('MONKET_BASE', '/~karl/monket-calendar/monket-cal-source/');
    define('MONKET_FILE_BASE', '/Users/karl/Sites/monket-calendar/monket-cal-source/');

    define('DEFAULT_CALENDAR', 'Home');
?>
